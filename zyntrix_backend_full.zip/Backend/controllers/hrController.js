const Attendance   = require("../models/attendance");
const ShiftRequest = require("../models/ShiftRequest");
const User         = require("../models/user");

function getUTCDate() {
  return new Date().toISOString().slice(0, 10);
}

function checkHrAccess(req, res) {
  if (!["hr", "super_admin"].includes(req.user.role)) {
    res.status(403).json({ msg: "Access denied" });
    return false;
  }
  return true;
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
exports.getDashboard = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const today = getUTCDate();

    const [employees, todayAttendance, pendingRequests] = await Promise.all([
      User.find({ role: "employee" }).select("name email role"),
      Attendance.find({ date: today }).select("userId punchIn"),
      ShiftRequest.countDocuments({ status: "pending" })
    ]);

    const presentSet = new Set(
      todayAttendance.filter(r => r.punchIn).map(r => String(r.userId))
    );

    const rows = employees.map(emp => ({
      id:     emp._id,
      name:   emp.name,
      email:  emp.email,
      role:   emp.role,
      status: presentSet.has(String(emp._id)) ? "Present" : "Absent"
    }));

    return res.json({
      stats: {
        totalEmployees:      employees.length,
        presentToday:        presentSet.size,
        absentToday:         Math.max(0, employees.length - presentSet.size),
        pendingShiftRequests: pendingRequests
      },
      employees: rows
    });

  } catch (err) {
    console.error("HR DASHBOARD ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── SHIFT REQUESTS ────────────────────────────────────────────────────────────
exports.getShiftRequests = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const query = {};
    if (req.query.status) query.status = req.query.status;
    if (req.query.userId) query.userId = req.query.userId;

    const requests = await ShiftRequest.find(query)
      .populate("userId",     "name email")
      .populate("reviewedBy", "name email")
      .sort({ date: 1, createdAt: -1 });

    return res.json(requests);
  } catch (err) {
    console.error("HR GET SHIFT REQUESTS ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── UPDATE SHIFT REQUEST STATUS ───────────────────────────────────────────────
exports.updateShiftRequestStatus = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const { status, reviewRemarks = "" } = req.body;

    if (!["approved", "rejected"].includes(status)) {
      return res.status(400).json({ msg: "status must be approved or rejected" });
    }

    const updated = await ShiftRequest.findByIdAndUpdate(
      req.params.id,
      {
        status,
        reviewRemarks: reviewRemarks.toString().slice(0, 500),
        reviewedBy:    req.user.id,
        reviewedAt:    new Date()
      },
      { returnDocument: "after" }
    ).populate("userId", "name email");

    if (!updated) return res.status(404).json({ msg: "Shift request not found" });

    return res.json(updated);
  } catch (err) {
    console.error("HR UPDATE SHIFT REQUEST ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── EMPLOYEE ATTENDANCE ───────────────────────────────────────────────────────
exports.getEmployeeAttendance = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const { userId } = req.params;
    const month = req.query.month || new Date().toISOString().slice(0, 7);

    if (!/^\d{4}-\d{2}$/.test(month)) {
      return res.status(400).json({ msg: "month must be YYYY-MM" });
    }

    const [year, monthNumber] = month.split("-").map(Number);
    const start = new Date(year, monthNumber - 1, 1);
    const end   = new Date(year, monthNumber,     1);

    const [user, data] = await Promise.all([
      User.findById(userId).select("name email role"),
      Attendance.find({
        userId,
        date: {
          $gte: start.toISOString().slice(0, 10),
          $lt:  end.toISOString().slice(0, 10)
        }
      }).sort({ date: 1 })
    ]);

    if (!user) return res.status(404).json({ msg: "User not found" });

    return res.json({ user, records: data });
  } catch (err) {
    console.error("HR GET EMPLOYEE ATTENDANCE ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── LIST ALL EMPLOYEES (with login accounts) ──────────────────────────────────
exports.getEmployees = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const { search, department, status, type } = req.query;
    const query = { role: "employee" };

    if (department) query.department = department;
    if (status)     query.employeeStatus = status;
    if (type)       query.employeeType   = type;
    if (search) {
      query.$or = [
        { name:  { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { designation: { $regex: search, $options: "i" } }
      ];
    }

    const employees = await User.find(query)
      .select("-password -otpCode -otpExpiry -otpResetToken")
      .populate("reportingTo", "name designation")
      .sort({ createdAt: -1 });

    return res.json({ employees, total: employees.length });
  } catch (err) {
    console.error("GET EMPLOYEES ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── GET SINGLE EMPLOYEE PROFILE ───────────────────────────────────────────────
exports.getEmployee = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const emp = await User.findOne({ _id: req.params.id, role: "employee" })
      .select("-password -otpCode -otpExpiry -otpResetToken")
      .populate("reportingTo", "name designation department");

    if (!emp) return res.status(404).json({ msg: "Employee not found" });

    // also get their attendance summary for current month
    const month = new Date().toISOString().slice(0, 7);
    const [year, monthNum] = month.split("-").map(Number);
    const start = new Date(year, monthNum - 1, 1).toISOString().slice(0, 10);
    const end   = new Date(year, monthNum,     1).toISOString().slice(0, 10);

    const attendance = await require("../models/attendance").find({
      userId: emp._id,
      date: { $gte: start, $lt: end }
    }).sort({ date: 1 });

    return res.json({ employee: emp, attendance });
  } catch (err) {
    console.error("GET EMPLOYEE ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── UPDATE EMPLOYEE PROFILE (HR edits) ───────────────────────────────────────
exports.updateEmployee = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    // Fields HR is allowed to update (NOT password, NOT role to admin)
    const allowed = [
      "name","phone","department","designation","employeeType",
      "dateOfJoining","salary","reportingTo","employeeStatus",
      "address","emergencyContact","profileNote"
    ];

    const update = {};
    allowed.forEach(f => { if (req.body[f] !== undefined) update[f] = req.body[f]; });

    const emp = await User.findOneAndUpdate(
      { _id: req.params.id, role: "employee" },
      update,
      { new: true, runValidators: true }
    ).select("-password -otpCode -otpExpiry -otpResetToken");

    if (!emp) return res.status(404).json({ msg: "Employee not found" });
    return res.json({ msg: "Updated", employee: emp });
  } catch (err) {
    console.error("UPDATE EMPLOYEE ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── CREATE EMPLOYEE ACCOUNT (HR creates login + profile) ─────────────────────
exports.createEmployee = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const {
      name, email, password,
      phone, department, designation, employeeType,
      dateOfJoining, salary, reportingTo, address,
      emergencyContact, profileNote
    } = req.body;

    if (!name || !email || !password)
      return res.status(400).json({ msg: "name, email and password are required" });

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ msg: "An account with this email already exists" });

    const bcrypt = require("bcryptjs");
    const hashed = await bcrypt.hash(password, 12);

    const emp = await User.create({
      name, email,
      password: hashed,
      role: "employee",
      phone, department, designation,
      employeeType: employeeType || "Full-time",
      dateOfJoining, salary,
      reportingTo: reportingTo || null,
      address, emergencyContact, profileNote,
      employeeStatus: "Active"
    });

    const safe = emp.toObject();
    delete safe.password;
    delete safe.otpCode;
    delete safe.otpExpiry;
    delete safe.otpResetToken;

    return res.status(201).json({ msg: "Employee created", employee: safe });
  } catch (err) {
    console.error("CREATE EMPLOYEE ERROR:", err);
    return res.status(500).json({ msg: "Server error: " + err.message });
  }
};

// ── DELETE / TERMINATE EMPLOYEE ───────────────────────────────────────────────
exports.terminateEmployee = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const { action } = req.body; // "terminate" | "delete"

    if (action === "delete") {
      // Hard delete — only super_admin
      if (req.user.role !== "super_admin")
        return res.status(403).json({ msg: "Only super_admin can permanently delete employees" });

      await User.findOneAndDelete({ _id: req.params.id, role: "employee" });
      return res.json({ msg: "Employee permanently deleted" });
    }

    // Default: soft-terminate (keep account, mark as Terminated)
    const emp = await User.findOneAndUpdate(
      { _id: req.params.id, role: "employee" },
      { employeeStatus: "Terminated" },
      { new: true }
    ).select("-password -otpCode -otpExpiry -otpResetToken");

    if (!emp) return res.status(404).json({ msg: "Employee not found" });
    return res.json({ msg: "Employee terminated", employee: emp });
  } catch (err) {
    console.error("TERMINATE EMPLOYEE ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── LIST DEPARTMENTS (derived from employees) ─────────────────────────────────
exports.getDepartments = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;
    const depts = await User.distinct("department", { role: "employee", department: { $ne: "" } });
    return res.json({ departments: depts.filter(Boolean).sort() });
  } catch (err) {
    return res.status(500).json({ msg: "Server error" });
  }
};

// ── HRMS DASHBOARD (real data) ────────────────────────────────────────────────
exports.getHrmsDashboard = async (req, res) => {
  try {
    if (!checkHrAccess(req, res)) return;

    const today = getUTCDate();

    const [
      totalEmployees,
      activeEmployees,
      todayAttendance,
      pendingRequests,
      deptBreakdown,
      recentHires
    ] = await Promise.all([
      User.countDocuments({ role: "employee" }),
      User.countDocuments({ role: "employee", employeeStatus: "Active" }),
      require("../models/attendance").find({ date: today }).select("userId punchIn"),
      ShiftRequest.countDocuments({ status: "pending" }),
      User.aggregate([
        { $match: { role: "employee", department: { $ne: "" } } },
        { $group: { _id: "$department", count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      User.find({ role: "employee" })
        .sort({ createdAt: -1 })
        .limit(5)
        .select("name designation department employeeStatus createdAt")
    ]);

    const presentSet = new Set(
      todayAttendance.filter(r => r.punchIn).map(r => String(r.userId))
    );

    return res.json({
      stats: {
        totalEmployees,
        activeEmployees,
        presentToday:  presentSet.size,
        absentToday:   Math.max(0, activeEmployees - presentSet.size),
        pendingRequests
      },
      deptBreakdown,
      recentHires
    });
  } catch (err) {
    console.error("HRMS DASHBOARD ERROR:", err);
    return res.status(500).json({ msg: "Server error" });
  }
};
